"""
rag_engine.py

Core RAG logic for the Technical Documentation Assistant.

Pipeline:
1. Convert question into embedding
2. Semantic search using ChromaDB
3. Calculate similarity
4. Apply grounding threshold
5. Refuse if documentation is not relevant
6. Send ONLY retrieved documentation to Groq
7. Return answer + sources
"""

import os

import chromadb
from sentence_transformers import SentenceTransformer
from groq import Groq


# =========================================================
# Configuration
# =========================================================

CHROMA_PATH = "chroma_db"
COLLECTION_NAME = "fastapi_docs"

# MUST match ingest.py
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# Groq model
LLM_MODEL = "openai/gpt-oss-120b"

# Grounding threshold
SIMILARITY_THRESHOLD = 0.25

# Number of chunks retrieved
TOP_K = 4


# =========================================================
# System Prompt
# =========================================================

SYSTEM_PROMPT = """
You are a technical documentation assistant.

Your job is to answer questions ONLY using the
documentation provided in the CONTEXT.

STRICT GROUNDING RULES:

1. Use only information present in the CONTEXT.

2. Do NOT use your own knowledge.

3. Do NOT assume information that is not present
   in the CONTEXT.

4. Do NOT invent APIs, functions, parameters,
   examples, versions, or configuration options.

5. If the CONTEXT does not contain enough information
   to answer the question, respond exactly:

"I don't have enough information in the documentation to answer that."

6. Mention the documentation source file used.

7. Keep the answer concise and technically accurate.

8. The CONTEXT is the ONLY source of truth.
"""


# =========================================================
# RAG Engine
# =========================================================

class RAGEngine:

    def __init__(
        self,
        api_key: str | None = None
    ):

        # -------------------------------------------------
        # Load embedding model
        # -------------------------------------------------

        print(
            f"Loading embedding model: "
            f"{EMBEDDING_MODEL}"
        )

        self.embed_model = SentenceTransformer(
            EMBEDDING_MODEL
        )

        # -------------------------------------------------
        # Connect to ChromaDB
        # -------------------------------------------------

        print(
            f"Loading ChromaDB from: "
            f"{CHROMA_PATH}"
        )

        client = chromadb.PersistentClient(
            path=CHROMA_PATH
        )

        try:

            self.collection = client.get_collection(
                name=COLLECTION_NAME
            )

        except Exception as e:

            raise ValueError(
                "Knowledge base collection not found. "
                "Run 'python ingest.py' first."
            ) from e

        count = self.collection.count()

        print(
            f"Knowledge base loaded: "
            f"{count} chunks"
        )

        if count == 0:

            raise ValueError(
                "Knowledge base is empty. "
                "Add .md files to knowledge_base/ "
                "and run 'python ingest.py'."
            )

        # -------------------------------------------------
        # Groq Client
        # -------------------------------------------------

        key = (
            api_key
            or os.environ.get("GROQ_API_KEY")
        )

        if not key:

            raise ValueError(
                "GROQ_API_KEY is not configured."
            )

        self.llm = Groq(
            api_key=key
        )

    # =====================================================
    # Semantic Retrieval
    # =====================================================

    def retrieve(
        self,
        query: str,
        k: int = TOP_K
    ) -> list[dict]:

        """
        Convert question into embedding and perform
        semantic similarity search.
        """

        collection_count = (
            self.collection.count()
        )

        if collection_count == 0:
            return []

        # -------------------------------------------------
        # Create query embedding
        # -------------------------------------------------

        query_embedding = self.embed_model.encode(
            [query],
            normalize_embeddings=True
        ).tolist()

        # -------------------------------------------------
        # Search ChromaDB
        # -------------------------------------------------

        results = self.collection.query(
            query_embeddings=query_embedding,
            n_results=min(
                k,
                collection_count
            ),
            include=[
                "documents",
                "metadatas",
                "distances"
            ]
        )

        if not results.get("documents"):
            return []

        documents = results["documents"][0]
        metadatas = results["metadatas"][0]
        distances = results["distances"][0]

        hits = []

        # -------------------------------------------------
        # Convert cosine distance → similarity
        # -------------------------------------------------

        for document, metadata, distance in zip(
            documents,
            metadatas,
            distances
        ):

            similarity = 1.0 - distance

            hits.append({
                "text": document,
                "source": metadata["source"],
                "chunk_index": metadata.get(
                    "chunk_index",
                    0
                ),
                "score": similarity
            })

        # Highest similarity first
        hits.sort(
            key=lambda x: x["score"],
            reverse=True
        )

        return hits

    # =====================================================
    # Build Grounded Prompt
    # =====================================================

    def _build_prompt(
        self,
        query: str,
        hits: list[dict]
    ) -> str:

        context_blocks = []

        for hit in hits:

            block = (
                f"[Source: {hit['source']}]\n"
                f"[Similarity: {hit['score']:.3f}]\n\n"
                f"{hit['text']}"
            )

            context_blocks.append(block)

        context = (
            "\n\n--------------------\n\n"
            .join(context_blocks)
        )

        prompt = f"""
CONTEXT:

{context}


QUESTION:

{query}


INSTRUCTIONS:

Answer the QUESTION using ONLY the CONTEXT.

Do not use outside knowledge.

Do not invent information.

If the CONTEXT does not contain enough information,
respond exactly:

"I don't have enough information in the documentation to answer that."

At the end of the answer include:

Source: <documentation filename>
"""

        return prompt

    # =====================================================
    # Generate Answer
    # =====================================================

    def answer(
        self,
        query: str,
        k: int = TOP_K
    ) -> dict:

        # -------------------------------------------------
        # Step 1: Retrieve
        # -------------------------------------------------

        hits = self.retrieve(
            query,
            k=k
        )

        # -------------------------------------------------
        # Step 2: No results
        # -------------------------------------------------

        if not hits:

            return {
                "answer": (
                    "I don't have enough information "
                    "in the documentation to answer that."
                ),
                "grounded": False,
                "sources": []
            }

        # -------------------------------------------------
        # Step 3: Grounding check
        # -------------------------------------------------

        best_score = hits[0]["score"]

        print(
            f"\nQuery: {query}"
        )

        print(
            f"Best similarity: "
            f"{best_score:.3f}"
        )

        print(
            f"Threshold: "
            f"{SIMILARITY_THRESHOLD:.3f}"
        )

        # If not relevant → DON'T call Groq
        if best_score < SIMILARITY_THRESHOLD:

            return {
                "answer": (
                    "I don't have enough information "
                    "in the documentation to answer that. "
                    "This question appears to be outside "
                    "the scope of the current knowledge base."
                ),
                "grounded": False,
                "sources": []
            }

        # -------------------------------------------------
        # Step 4: Build prompt
        # -------------------------------------------------

        prompt = self._build_prompt(
            query,
            hits
        )

        # -------------------------------------------------
        # Step 5: Call Groq
        # -------------------------------------------------

        response = self.llm.chat.completions.create(
            model=LLM_MODEL,

            messages=[
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],

            temperature=0
        )

        # -------------------------------------------------
        # Step 6: Extract answer
        # -------------------------------------------------

        answer_text = (
            response
            .choices[0]
            .message
            .content
        )

        # -------------------------------------------------
        # Step 7: Return answer + sources
        # -------------------------------------------------

        return {
            "answer": answer_text.strip(),
            "grounded": True,
            "sources": hits
        }