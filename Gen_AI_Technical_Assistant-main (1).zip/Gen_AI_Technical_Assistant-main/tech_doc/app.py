"""
app.py

Streamlit chat UI for the FastAPI Documentation RAG Assistant.

Run with:
    python -m streamlit run app.py

Requires:
    1. Knowledge base created using ingest.py
    2. GROQ_API_KEY configured in .env
"""

import os

import streamlit as st

from rag_engine import RAGEngine, TOP_K

from dotenv import load_dotenv


# =========================================================
# Load Environment Variables
# =========================================================

load_dotenv()


# =========================================================
# Page Configuration
# =========================================================

st.set_page_config(
    page_title="FastAPI Documentation Assistant",
    page_icon="📘",
    layout="wide"
)


# =========================================================
# Header
# =========================================================

st.title("📘 FastAPI Documentation Assistant")

st.caption(
    "A RAG chatbot grounded in a local FastAPI knowledge base. "
    "It answers questions only from the available documentation."
)


# =========================================================
# Load RAG Engine
# =========================================================

@st.cache_resource(
    show_spinner="Loading knowledge base..."
)
def get_engine():

    api_key = os.environ.get(
        "GROQ_API_KEY"
    )

    if not api_key:

        raise ValueError(
            "GROQ_API_KEY is not configured. "
            "Please add it to your .env file."
        )

    return RAGEngine(
        api_key=api_key
    )


# =========================================================
# Initialize Engine
# =========================================================

try:

    engine = get_engine()

except Exception as e:

    st.error(
        f"Unable to load the application.\n\n"
        f"Error: {e}"
    )

    st.stop()


# =========================================================
# Chat State
# =========================================================

if "messages" not in st.session_state:

    st.session_state.messages = []


# =========================================================
# Clear Chat Button
# =========================================================

if st.button("🗑️ Clear Chat"):

    st.session_state.messages = []

    st.rerun()


# =========================================================
# Display Previous Messages
# =========================================================

for msg in st.session_state.messages:

    with st.chat_message(
        msg["role"]
    ):

        st.markdown(
            msg["content"]
        )

        # Show sources
        if msg.get("sources"):

            with st.expander(
                "📎 Sources"
            ):

                for source in msg["sources"]:

                    st.markdown(
                        f"**{source['source']}** "
                        f"— similarity "
                        f"`{source['score']:.3f}`"
                    )

                    st.caption(
                        source["text"][:300]
                        +
                        (
                            "..."
                            if len(source["text"]) > 300
                            else ""
                        )
                    )


# =========================================================
# Chat Input
# =========================================================

if query := st.chat_input(
    "Ask something about FastAPI..."
):

    # -----------------------------------------------------
    # Display User Message
    # -----------------------------------------------------

    st.session_state.messages.append(
        {
            "role": "user",
            "content": query
        }
    )

    with st.chat_message("user"):

        st.markdown(query)

    # -----------------------------------------------------
    # Generate Answer
    # -----------------------------------------------------

    with st.chat_message("assistant"):

        with st.spinner(
            "Searching documentation..."
        ):

            try:

                result = engine.answer(
                    query,
                    k=TOP_K
                )

            except Exception as e:

                st.error(
                    f"Error while generating answer: {e}"
                )

                st.stop()

        # -------------------------------------------------
        # Display Answer
        # -------------------------------------------------

        st.markdown(
            result["answer"]
        )

        # -------------------------------------------------
        # Display Sources
        # -------------------------------------------------

        if result["grounded"]:

            with st.expander(
                f"📎 Sources ({len(result['sources'])})"
            ):

                for source in result["sources"]:

                    st.markdown(
                        f"**{source['source']}** "
                        f"— similarity "
                        f"`{source['score']:.3f}`"
                    )

                    st.caption(
                        source["text"][:300]
                        +
                        (
                            "..."
                            if len(source["text"]) > 300
                            else ""
                        )
                    )

        else:

            st.info(
                "No sources used — this question "
                "is outside the knowledge base."
            )

    # -----------------------------------------------------
    # Save Assistant Message
    # -----------------------------------------------------

    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": result["answer"],
            "sources": (
                result["sources"]
                if result["grounded"]
                else None
            )
        }
    )