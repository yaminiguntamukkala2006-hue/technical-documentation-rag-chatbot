"""
ingest.py

Builds the knowledge base for the RAG chatbot:
1. Loads every .md file from ./knowledge_base
2. Splits each file into overlapping chunks
3. Embeds each chunk with SentenceTransformers
4. Stores chunks + embeddings + metadata in ChromaDB

Run:
    python ingest.py
"""

import os
import glob
import chromadb
from sentence_transformers import SentenceTransformer


# =========================================================
# Configuration
# =========================================================

KB_DIR = "knowledge_base"
CHROMA_PATH = "chroma_db"
COLLECTION_NAME = "fastapi_docs"

# Must be the SAME model used in rag_engine.py
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

CHUNK_SIZE = 800
CHUNK_OVERLAP = 150


# =========================================================
# Load Documents
# =========================================================

def load_documents(kb_dir: str) -> list[dict]:

    docs = []

    for path in sorted(
        glob.glob(os.path.join(kb_dir, "*.md"))
    ):

        with open(path, "r", encoding="utf-8") as f:
            text = f.read().strip()

        if text:
            docs.append({
                "source": os.path.basename(path),
                "text": text
            })

    return docs


# =========================================================
# Chunk Documents
# =========================================================

def chunk_text(
    text: str,
    chunk_size: int,
    overlap: int
) -> list[str]:

    paragraphs = [
        p.strip()
        for p in text.split("\n\n")
        if p.strip()
    ]

    chunks = []
    current = ""

    for para in paragraphs:

        if len(current) + len(para) + 2 <= chunk_size:

            current = (
                f"{current}\n\n{para}"
                if current
                else para
            )

        else:

            if current:
                chunks.append(current)

            overlap_text = (
                current[-overlap:]
                if current
                else ""
            )

            current = (
                f"{overlap_text}\n\n{para}".strip()
                if overlap_text
                else para
            )

            while len(current) > chunk_size:

                chunks.append(
                    current[:chunk_size]
                )

                current = current[
                    chunk_size - overlap:
                ]

    if current:
        chunks.append(current)

    return chunks


# =========================================================
# Build Knowledge Base
# =========================================================

def build_knowledge_base():

    print("=" * 60)
    print("FASTAPI DOCUMENTATION KNOWLEDGE BASE")
    print("=" * 60)

    # -----------------------------------------------------
    # Load documents
    # -----------------------------------------------------

    print(
        f"\nLoading documents from '{KB_DIR}/'..."
    )

    docs = load_documents(KB_DIR)

    print(
        f"Found {len(docs)} documents."
    )

    if not docs:
        raise FileNotFoundError(
            f"\nNo .md files found in '{KB_DIR}/'.\n\n"
            "Please add your FastAPI documentation files."
        )

    # -----------------------------------------------------
    # Load embedding model
    # -----------------------------------------------------

    print(
        f"\nLoading embedding model "
        f"'{EMBEDDING_MODEL}'..."
    )

    model = SentenceTransformer(
        EMBEDDING_MODEL
    )

    # -----------------------------------------------------
    # Connect to ChromaDB
    # -----------------------------------------------------

    print("\nConnecting to ChromaDB...")

    client = chromadb.PersistentClient(
        path=CHROMA_PATH
    )

    # Delete previous collection
    try:
        client.delete_collection(
            name=COLLECTION_NAME
        )
        print("Old collection deleted.")
    except Exception:
        pass

    collection = client.create_collection(
        name=COLLECTION_NAME,
        metadata={
            "hnsw:space": "cosine"
        }
    )

    # -----------------------------------------------------
    # Create chunks
    # -----------------------------------------------------

    all_chunks = []
    all_metadatas = []
    all_ids = []

    for doc in docs:

        chunks = chunk_text(
            doc["text"],
            CHUNK_SIZE,
            CHUNK_OVERLAP
        )

        print(
            f"  {doc['source']}: "
            f"{len(chunks)} chunks"
        )

        for i, chunk in enumerate(chunks):

            all_chunks.append(chunk)

            all_metadatas.append({
                "source": doc["source"],
                "chunk_index": i
            })

            all_ids.append(
                f"{doc['source']}::{i}"
            )

    print(
        f"\nCreated {len(all_chunks)} chunks "
        f"across {len(docs)} documents."
    )

    if not all_chunks:
        raise ValueError(
            "No chunks were created."
        )

    # -----------------------------------------------------
    # Generate embeddings
    # -----------------------------------------------------

    print("\nComputing embeddings...")

    embeddings = model.encode(
        all_chunks,
        show_progress_bar=True,
        normalize_embeddings=True
    ).tolist()

    # -----------------------------------------------------
    # Store in ChromaDB
    # -----------------------------------------------------

    print("\nWriting to ChromaDB...")

    BATCH_SIZE = 100

    for start in range(
        0,
        len(all_chunks),
        BATCH_SIZE
    ):

        end = start + BATCH_SIZE

        collection.add(
            documents=all_chunks[start:end],
            embeddings=embeddings[start:end],
            metadatas=all_metadatas[start:end],
            ids=all_ids[start:end]
        )

    # -----------------------------------------------------
    # Finished
    # -----------------------------------------------------

    print("\n" + "=" * 60)

    print(
        f"Done! Collection '{COLLECTION_NAME}' "
        f"now has {collection.count()} chunks."
    )

    print(
        f"Vector store persisted at "
        f"./{CHROMA_PATH}"
    )

    print("=" * 60)


# =========================================================
# Main
# =========================================================

if __name__ == "__main__":
    build_knowledge_base()