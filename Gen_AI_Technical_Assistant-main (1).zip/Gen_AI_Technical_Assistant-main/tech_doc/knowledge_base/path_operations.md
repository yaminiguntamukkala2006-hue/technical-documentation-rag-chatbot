
---

# 2. `path_operations.md`

```markdown
# FastAPI Path Operations

## Definition

A path operation connects a URL path and an HTTP method to a Python
function.

For example:

```python
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World"}