
---

# 8. `error_handling.md`

```markdown
# FastAPI Error Handling

FastAPI provides mechanisms for handling errors and returning
appropriate HTTP responses.

## HTTPException

FastAPI provides `HTTPException` for returning HTTP errors.

Example:

```python
from fastapi import FastAPI, HTTPException

app = FastAPI()

@app.get("/items/{item_id}")
async def read_item(item_id: int):

    if item_id == 0:
        raise HTTPException(
            status_code=404,
            detail="Item not found"
        )

    return {
        "item_id": item_id
    }