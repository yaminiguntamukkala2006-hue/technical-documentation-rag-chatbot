# FastAPI Introduction

## What is FastAPI?

FastAPI is a modern Python web framework for building APIs.

It is based on Python type hints and provides automatic validation,
serialization, and interactive API documentation.

## Creating a FastAPI application

```python
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World"}