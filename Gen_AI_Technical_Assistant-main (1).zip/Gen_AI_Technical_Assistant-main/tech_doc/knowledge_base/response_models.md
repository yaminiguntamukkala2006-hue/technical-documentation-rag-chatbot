
---

# 5. `response_models.md`

```markdown
# FastAPI Response Models

FastAPI can use Pydantic models to define the structure of API
responses.

## response_model

The `response_model` parameter can be used to define the expected
response structure.

Example:

```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Item(BaseModel):
    name: str
    price: float

@app.get("/items/", response_model=Item)
async def read_item():
    return {
        "name": "Laptop",
        "price": 50000
    }