
---

# 4. `request_body.md`

```markdown
# FastAPI Request Body

A request body contains data sent by the client to the API.

FastAPI commonly uses Pydantic models to define and validate request
bodies.

## Pydantic Model

A request body can be defined using a Pydantic model.

```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Item(BaseModel):
    name: str
    price: float
    description: str | None = None

@app.post("/items/")
async def create_item(item: Item):
    return item