
---

# 7. `security.md`

```markdown
# FastAPI Security

FastAPI provides tools for implementing authentication and
authorization.

Security utilities can be used together with FastAPI dependencies.

## OAuth2

OAuth2 is a specification that provides different ways for an
application to obtain an access token.

FastAPI provides utilities for implementing OAuth2-based security.

## OAuth2PasswordBearer

`OAuth2PasswordBearer` can be used to define an OAuth2 security scheme.

Example:

```python
from typing import Annotated

from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

app = FastAPI()

oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="token"
)

@app.get("/items/")
async def read_items(
    token: Annotated[str, Depends(oauth2_scheme)]
):
    return {
        "token": token
    }