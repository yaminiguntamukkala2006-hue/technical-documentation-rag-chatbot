
---

# 3. `parameters.md`

```markdown
# FastAPI Parameters

FastAPI supports path parameters and query parameters.

## Path Parameters

A path parameter is a variable included in the URL path.

Example:

```python
from fastapi import FastAPI

app = FastAPI()

@app.get("/items/{item_id}")
async def read_item(item_id: int):
    return {"item_id": item_id}